import React from 'react'
import './footer.css'

function Footer() {
  return (
   <>
   <div className="footer-container">
    <div className="content footer-text-style">Copyrights © 2023 STUDI. All Rights Reserved.</div>
    <div className="line"></div>
   </div>
   </>
  )
}

export default Footer